package com.prashant.shopeasy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopeasyApplicationTests {

	@Test
	void contextLoads() {
	}

}
