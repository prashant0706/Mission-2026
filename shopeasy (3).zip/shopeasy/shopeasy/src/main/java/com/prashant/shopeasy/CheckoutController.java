package com.prashant.shopeasy;

import com.prashant.shopeasy.model.Cart;
import com.prashant.shopeasy.model.Order;
import com.prashant.shopeasy.model.User;
import com.prashant.shopeasy.service.OrderService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CheckoutController {

    @Autowired
    private OrderService orderService;

    // Get cart from session
    private Cart getCart(HttpSession session) {
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }
        return cart;
    }

    // Show checkout page
    @GetMapping("/checkout")
    public String showCheckout(HttpSession session, Model model) {
        Cart cart = getCart(session);
        
        if (cart.getItems().isEmpty()) {
            return "redirect:/cart";
        }
        
        // Pre-fill form if user is logged in
        User user = (User) session.getAttribute("loggedInUser");
        if (user != null) {
            model.addAttribute("user", user);
        }
        
        model.addAttribute("cart", cart);
        return "checkout";
    }

    // Process checkout
    @PostMapping("/checkout")
    public String processCheckout(@RequestParam String name,
                                  @RequestParam String email,
                                  @RequestParam String phone,
                                  @RequestParam String address,
                                  HttpSession session,
                                  Model model) {
        Cart cart = getCart(session);
        
        if (cart.getItems().isEmpty()) {
            return "redirect:/cart";
        }
        
        // Create order
        Order order = orderService.createOrder(cart, name, email, phone, address);
        
        // Clear the cart
        session.removeAttribute("cart");
        
        // Store order ID for confirmation page
        session.setAttribute("lastOrderId", order.getId());
        
        return "redirect:/order-confirmation/" + order.getId();
    }

    // Order confirmation page
    @GetMapping("/order-confirmation/{orderId}")
    public String showOrderConfirmation(@PathVariable int orderId, Model model) {
        Order order = orderService.getOrderById(orderId);
        
        if (order == null) {
            return "redirect:/";
        }
        
        model.addAttribute("order", order);
        return "order-confirmation";
    }

    // My orders page
    @GetMapping("/my-orders")
    public String showMyOrders(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        
        if (user == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("orders", orderService.getOrdersByEmail(user.getEmail()));
        return "my-orders";
    }
}
