package com.prashant.shopeasy.service;

import com.prashant.shopeasy.model.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    private List<Product> products = new ArrayList<>();

    // Constructor - initialize products with more variety
    public ProductService() {
        // Smartphones
        products.add(new Product(1, "iPhone 15 Pro", "Latest Apple smartphone with A17 chip", 134900.00, "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-15-pro-finish-select-202309-6-1inch_GEO_EMEA?wid=300", "Smartphones"));
        products.add(new Product(2, "Samsung Galaxy S24", "Flagship Android smartphone with AI features", 79999.00, "https://images.samsung.com/is/image/samsung/p6pim/in/2401/gallery/in-galaxy-s24-sm-s921blbgins-thumb-539573138?wid=300", "Smartphones"));
        products.add(new Product(3, "OnePlus 12", "Premium Android with Snapdragon 8 Gen 3", 64999.00, "https://oasis.opstatics.com/content/dam/oasis/page/2024/in/oneplus-12/specs/glacial-white.png", "Smartphones"));
        
        // Laptops
        products.add(new Product(4, "MacBook Air M3", "Thin and light laptop with M3 chip", 114900.00, "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/mba13-midnight-select-202402?wid=300", "Laptops"));
        products.add(new Product(5, "Dell XPS 15", "Premium Windows laptop with OLED display", 189990.00, "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/notebooks/xps-notebooks/xps-15-9530/media-gallery/black/notebook-xps-9530-t-black-gallery-4.psd?wid=300", "Laptops"));
        products.add(new Product(6, "HP Pavilion Gaming", "Gaming laptop with RTX 4050", 84999.00, "https://in-media.apjonlinecdn.com/catalog/product/cache/b3b166914d87ce343d4dc5ec5117b502/c/0/c08816017.png", "Laptops"));
        
        // Audio
        products.add(new Product(7, "Sony WH-1000XM5", "Premium noise cancelling headphones", 29990.00, "https://www.sony.co.in/image/5d02da5df552836db894cead8a68f5f3?fmt=pjpeg&wid=300", "Audio"));
        products.add(new Product(8, "Apple AirPods Pro 2", "Active noise cancelling earbuds", 24900.00, "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/MQD83?wid=300", "Audio"));
        products.add(new Product(9, "JBL Flip 6", "Portable Bluetooth speaker", 12999.00, "https://in.jbl.com/dw/image/v2/BFND_PRD/on/demandware.static/-/Sites-masterCatalog_Harman/default/dw395fcfd4/JBL_Flip6_Hero_Squad_RGB.png?sw=300", "Audio"));
        
        // Accessories
        products.add(new Product(10, "Apple Watch Ultra 2", "Premium smartwatch for athletes", 89900.00, "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/MQDY3ref_VW_34FR+watch-49-titanium-702-702_VW_34FR_WF_CO+watch-face-49-alpine-702-702_VW_34FR_WF_CO?wid=300", "Accessories"));
        products.add(new Product(11, "Samsung Galaxy Watch 6", "Premium Android smartwatch", 34999.00, "https://images.samsung.com/is/image/samsung/p6pim/in/2307/gallery/in-galaxy-watch6-sm-r930nzkainu-thumb-536858825?wid=300", "Accessories"));
        products.add(new Product(12, "Logitech MX Master 3S", "Premium wireless mouse", 10995.00, "https://resource.logitech.com/w_386,ar_1.0,c_limit,f_auto,q_auto,dpr_2.0/d_transparent.gif/content/dam/logitech/en/products/mice/mx-master-3s/gallery/mx-master-3s-mouse-top-view-graphite.png", "Accessories"));
    }

    // Get all products
    public List<Product> getAllProducts() {
        return products;
    }

    // Find product by ID
    public Product getProductById(int id) {
        for (Product product : products) {
            if (product.getId() == id) {
                return product;
            }
        }
        return null;
    }

    // Search products by name or description
    public List<Product> searchProducts(String query) {
        if (query == null || query.trim().isEmpty()) {
            return products;
        }
        
        String searchTerm = query.toLowerCase().trim();
        return products.stream()
                .filter(p -> p.getName().toLowerCase().contains(searchTerm) ||
                            p.getDescription().toLowerCase().contains(searchTerm) ||
                            p.getCategory().toLowerCase().contains(searchTerm))
                .collect(Collectors.toList());
    }

    // Get products by category
    public List<Product> getProductsByCategory(String category) {
        if (category == null || category.trim().isEmpty() || category.equalsIgnoreCase("all")) {
            return products;
        }
        
        return products.stream()
                .filter(p -> p.getCategory().equalsIgnoreCase(category))
                .collect(Collectors.toList());
    }

    // Get all categories
    public List<String> getAllCategories() {
        return products.stream()
                .map(Product::getCategory)
                .distinct()
                .collect(Collectors.toList());
    }
}