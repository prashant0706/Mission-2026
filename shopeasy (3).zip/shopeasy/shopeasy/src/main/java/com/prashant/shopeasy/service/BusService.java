package com.prashant.shopeasy.service;

import com.prashant.shopeasy.model.Bus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BusService {
    
    private List<Bus> buses = new ArrayList<>();
    
    public BusService() {
        initializeBuses();
    }
    
    private void initializeBuses() {
        LocalDate today = LocalDate.now();
        
        // Pune to Mumbai
        buses.add(new Bus(1, "MH-12-AB-1234", "Neeta Travels", "AC Sleeper", "Pune", "Mumbai", today.plusDays(1), LocalTime.of(6, 0), LocalTime.of(10, 0), 600, 30, "WiFi, Charging, Blanket"));
        buses.add(new Bus(2, "MH-12-CD-5678", "Purple Travels", "Volvo AC", "Pune", "Mumbai", today.plusDays(1), LocalTime.of(8, 30), LocalTime.of(12, 30), 750, 25, "WiFi, Charging, Water"));
        buses.add(new Bus(3, "MH-12-EF-9012", "VRL Travels", "Non-AC Seater", "Pune", "Mumbai", today.plusDays(1), LocalTime.of(22, 0), LocalTime.of(2, 0), 350, 40, "Charging"));
        
        // Pune to Bangalore
        buses.add(new Bus(4, "KA-01-MN-1234", "SRS Travels", "AC Sleeper", "Pune", "Bangalore", today.plusDays(1), LocalTime.of(18, 0), LocalTime.of(6, 0), 1200, 28, "WiFi, Charging, Blanket, Snacks"));
        buses.add(new Bus(5, "KA-01-OP-5678", "VRL Travels", "Volvo Multi-Axle", "Pune", "Bangalore", today.plusDays(2), LocalTime.of(20, 0), LocalTime.of(8, 0), 1500, 32, "WiFi, Charging, Blanket, Meal"));
        buses.add(new Bus(6, "MH-12-QR-9012", "Neeta Travels", "AC Semi-Sleeper", "Pune", "Bangalore", today.plusDays(2), LocalTime.of(21, 30), LocalTime.of(9, 30), 1100, 35, "WiFi, Charging"));
        
        // Mumbai to Goa
        buses.add(new Bus(7, "GA-01-AB-1234", "Paulo Travels", "Volvo AC Sleeper", "Mumbai", "Goa", today.plusDays(1), LocalTime.of(19, 0), LocalTime.of(7, 0), 1400, 26, "WiFi, Charging, Blanket, Dinner"));
        buses.add(new Bus(8, "GA-01-CD-5678", "Neeta Travels", "AC Sleeper", "Mumbai", "Goa", today.plusDays(2), LocalTime.of(20, 30), LocalTime.of(8, 30), 1200, 30, "WiFi, Charging, Blanket"));
        buses.add(new Bus(9, "MH-04-EF-9012", "Purple Travels", "Semi-Sleeper", "Mumbai", "Goa", today.plusDays(3), LocalTime.of(22, 0), LocalTime.of(10, 0), 900, 38, "Charging, Blanket"));
        
        // Delhi to Jaipur
        buses.add(new Bus(10, "RJ-14-GH-1234", "RSRTC", "Volvo AC", "Delhi", "Jaipur", today.plusDays(1), LocalTime.of(6, 0), LocalTime.of(11, 0), 800, 45, "AC, Charging"));
        buses.add(new Bus(11, "DL-01-IJ-5678", "Rajdhani Travels", "AC Sleeper", "Delhi", "Jaipur", today.plusDays(1), LocalTime.of(22, 0), LocalTime.of(5, 0), 950, 32, "WiFi, Charging, Blanket"));
        
        // Bangalore to Chennai
        buses.add(new Bus(12, "TN-01-KL-1234", "SRS Travels", "Volvo AC", "Bangalore", "Chennai", today.plusDays(1), LocalTime.of(6, 0), LocalTime.of(12, 0), 800, 40, "WiFi, Charging, Water"));
        buses.add(new Bus(13, "KA-01-MN-5678", "VRL Travels", "AC Seater", "Bangalore", "Chennai", today.plusDays(2), LocalTime.of(14, 0), LocalTime.of(20, 0), 650, 45, "Charging"));
        buses.add(new Bus(14, "TN-01-OP-9012", "KSRTC", "Non-AC", "Bangalore", "Chennai", today.plusDays(2), LocalTime.of(23, 0), LocalTime.of(6, 0), 400, 50, "Basic"));
        
        // Pune to Hyderabad
        buses.add(new Bus(15, "TS-01-QR-1234", "Orange Travels", "AC Sleeper", "Pune", "Hyderabad", today.plusDays(1), LocalTime.of(19, 0), LocalTime.of(5, 0), 1100, 28, "WiFi, Charging, Blanket, Snacks"));
        buses.add(new Bus(16, "TS-01-ST-5678", "VRL Travels", "Volvo Multi-Axle", "Pune", "Hyderabad", today.plusDays(3), LocalTime.of(21, 0), LocalTime.of(7, 0), 1350, 30, "WiFi, Charging, Blanket, Dinner"));
    }
    
    public List<Bus> getAllBuses() {
        return buses;
    }
    
    public Bus getBusById(int id) {
        return buses.stream().filter(b -> b.getId() == id).findFirst().orElse(null);
    }
    
    public List<Bus> searchBuses(String source, String destination, LocalDate date) {
        return buses.stream()
            .filter(b -> (source == null || source.isEmpty() || b.getSource().equalsIgnoreCase(source)))
            .filter(b -> (destination == null || destination.isEmpty() || b.getDestination().equalsIgnoreCase(destination)))
            .filter(b -> (date == null || b.getDepartureDate().equals(date)))
            .filter(b -> b.getAvailableSeats() > 0)
            .collect(Collectors.toList());
    }
    
    public List<String> getAllCities() {
        List<String> cities = new ArrayList<>();
        buses.forEach(b -> {
            if (!cities.contains(b.getSource())) cities.add(b.getSource());
            if (!cities.contains(b.getDestination())) cities.add(b.getDestination());
        });
        cities.sort(String::compareTo);
        return cities;
    }
    
    public List<String> getAllOperators() {
        return buses.stream().map(Bus::getOperatorName).distinct().sorted().collect(Collectors.toList());
    }
    
    public List<String> getAllBusTypes() {
        return buses.stream().map(Bus::getBusType).distinct().sorted().collect(Collectors.toList());
    }
    
    public boolean bookSeats(int busId, int seats) {
        Bus bus = getBusById(busId);
        if (bus != null && bus.getAvailableSeats() >= seats) {
            bus.setAvailableSeats(bus.getAvailableSeats() - seats);
            return true;
        }
        return false;
    }
}
