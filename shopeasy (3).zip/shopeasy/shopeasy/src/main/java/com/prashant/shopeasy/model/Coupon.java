package com.prashant.shopeasy.model;

public class Coupon {
    
    private int id;
    private String code;
    private String description;
    private int discountPercent;
    private double maxDiscount;
    private double minBookingAmount;
    private String validFrom;
    private String validTo;
    private boolean active;
    private String applicableFor; // FLIGHT, BUS, ALL
    
    public Coupon() {}
    
    public Coupon(int id, String code, String description, int discountPercent, 
                  double maxDiscount, double minBookingAmount, String validFrom, 
                  String validTo, boolean active, String applicableFor) {
        this.id = id;
        this.code = code;
        this.description = description;
        this.discountPercent = discountPercent;
        this.maxDiscount = maxDiscount;
        this.minBookingAmount = minBookingAmount;
        this.validFrom = validFrom;
        this.validTo = validTo;
        this.active = active;
        this.applicableFor = applicableFor;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public int getDiscountPercent() { return discountPercent; }
    public void setDiscountPercent(int discountPercent) { this.discountPercent = discountPercent; }
    
    public double getMaxDiscount() { return maxDiscount; }
    public void setMaxDiscount(double maxDiscount) { this.maxDiscount = maxDiscount; }
    
    public double getMinBookingAmount() { return minBookingAmount; }
    public void setMinBookingAmount(double minBookingAmount) { this.minBookingAmount = minBookingAmount; }
    
    public String getValidFrom() { return validFrom; }
    public void setValidFrom(String validFrom) { this.validFrom = validFrom; }
    
    public String getValidTo() { return validTo; }
    public void setValidTo(String validTo) { this.validTo = validTo; }
    
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    
    public String getApplicableFor() { return applicableFor; }
    public void setApplicableFor(String applicableFor) { this.applicableFor = applicableFor; }
}
