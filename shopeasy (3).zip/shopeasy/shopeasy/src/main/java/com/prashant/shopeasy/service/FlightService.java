package com.prashant.shopeasy.service;

import com.prashant.shopeasy.model.Flight;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FlightService {
    
    private List<Flight> flights = new ArrayList<>();
    
    public FlightService() {
        initializeFlights();
    }
    
    private void initializeFlights() {
        LocalDate today = LocalDate.now();
        
        // Pune to Mumbai
        flights.add(new Flight(1, "AI-101", "Air India", "Pune", "Mumbai", today.plusDays(1), LocalTime.of(6, 0), LocalTime.of(7, 0), 2500, 45, "Airbus A320"));
        flights.add(new Flight(2, "6E-201", "IndiGo", "Pune", "Mumbai", today.plusDays(1), LocalTime.of(9, 30), LocalTime.of(10, 30), 2200, 32, "ATR 72"));
        flights.add(new Flight(3, "SG-301", "SpiceJet", "Pune", "Mumbai", today.plusDays(2), LocalTime.of(14, 0), LocalTime.of(15, 0), 1999, 28, "Boeing 737"));
        
        // Pune to Delhi
        flights.add(new Flight(4, "AI-501", "Air India", "Pune", "Delhi", today.plusDays(1), LocalTime.of(7, 0), LocalTime.of(9, 15), 5500, 50, "Airbus A321"));
        flights.add(new Flight(5, "6E-701", "IndiGo", "Pune", "Delhi", today.plusDays(1), LocalTime.of(11, 0), LocalTime.of(13, 30), 4800, 42, "Airbus A320neo"));
        flights.add(new Flight(6, "UK-101", "Vistara", "Pune", "Delhi", today.plusDays(2), LocalTime.of(16, 0), LocalTime.of(18, 30), 6200, 38, "Boeing 737-800"));
        
        // Delhi to Goa
        flights.add(new Flight(7, "6E-801", "IndiGo", "Delhi", "Goa", today.plusDays(1), LocalTime.of(6, 30), LocalTime.of(9, 0), 4500, 55, "Airbus A320"));
        flights.add(new Flight(8, "AI-601", "Air India", "Delhi", "Goa", today.plusDays(2), LocalTime.of(10, 0), LocalTime.of(12, 45), 5200, 40, "Boeing 787"));
        flights.add(new Flight(9, "SG-401", "SpiceJet", "Delhi", "Goa", today.plusDays(3), LocalTime.of(14, 30), LocalTime.of(17, 0), 3999, 35, "Boeing 737 MAX"));
        
        // Mumbai to Bangalore
        flights.add(new Flight(10, "UK-201", "Vistara", "Mumbai", "Bangalore", today.plusDays(1), LocalTime.of(8, 0), LocalTime.of(9, 30), 4200, 48, "Airbus A320neo"));
        flights.add(new Flight(11, "6E-301", "IndiGo", "Mumbai", "Bangalore", today.plusDays(1), LocalTime.of(12, 0), LocalTime.of(13, 45), 3800, 52, "Airbus A321"));
        flights.add(new Flight(12, "AI-701", "Air India", "Mumbai", "Bangalore", today.plusDays(2), LocalTime.of(18, 0), LocalTime.of(19, 30), 4500, 44, "Boeing 737"));
        
        // Bangalore to Chennai
        flights.add(new Flight(13, "6E-401", "IndiGo", "Bangalore", "Chennai", today.plusDays(1), LocalTime.of(7, 0), LocalTime.of(7, 55), 2100, 60, "ATR 72"));
        flights.add(new Flight(14, "SG-501", "SpiceJet", "Bangalore", "Chennai", today.plusDays(2), LocalTime.of(15, 0), LocalTime.of(16, 0), 1899, 38, "Bombardier Q400"));
        
        // Pune to Hyderabad
        flights.add(new Flight(15, "AI-801", "Air India", "Pune", "Hyderabad", today.plusDays(1), LocalTime.of(9, 0), LocalTime.of(10, 15), 3200, 46, "Airbus A320"));
        flights.add(new Flight(16, "6E-501", "IndiGo", "Pune", "Hyderabad", today.plusDays(3), LocalTime.of(17, 0), LocalTime.of(18, 15), 2800, 50, "Airbus A320neo"));
    }
    
    public List<Flight> getAllFlights() {
        return flights;
    }
    
    public Flight getFlightById(int id) {
        return flights.stream().filter(f -> f.getId() == id).findFirst().orElse(null);
    }
    
    public List<Flight> searchFlights(String source, String destination, LocalDate date) {
        return flights.stream()
            .filter(f -> (source == null || source.isEmpty() || f.getSource().equalsIgnoreCase(source)))
            .filter(f -> (destination == null || destination.isEmpty() || f.getDestination().equalsIgnoreCase(destination)))
            .filter(f -> (date == null || f.getDepartureDate().equals(date)))
            .filter(f -> f.getAvailableSeats() > 0)
            .collect(Collectors.toList());
    }
    
    public List<String> getAllCities() {
        List<String> cities = new ArrayList<>();
        flights.forEach(f -> {
            if (!cities.contains(f.getSource())) cities.add(f.getSource());
            if (!cities.contains(f.getDestination())) cities.add(f.getDestination());
        });
        cities.sort(String::compareTo);
        return cities;
    }
    
    public List<String> getAllAirlines() {
        return flights.stream().map(Flight::getAirline).distinct().sorted().collect(Collectors.toList());
    }
    
    public boolean bookSeats(int flightId, int seats) {
        Flight flight = getFlightById(flightId);
        if (flight != null && flight.getAvailableSeats() >= seats) {
            flight.setAvailableSeats(flight.getAvailableSeats() - seats);
            return true;
        }
        return false;
    }
}
