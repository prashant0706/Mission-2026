package com.prashant.shopeasy.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Trip {
    
    private int id;
    private int userId;
    private String tripName;
    private String destination;
    private LocalDate startDate;
    private LocalDate endDate;
    private double budget;
    private double spentAmount;
    private String status; // PLANNING, UPCOMING, ONGOING, COMPLETED, CANCELLED
    private List<TripItem> items;
    private String notes;
    
    public Trip() {
        this.items = new ArrayList<>();
        this.status = "PLANNING";
        this.spentAmount = 0;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public String getTripName() { return tripName; }
    public void setTripName(String tripName) { this.tripName = tripName; }
    
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    
    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    
    public double getBudget() { return budget; }
    public void setBudget(double budget) { this.budget = budget; }
    
    public double getSpentAmount() { return spentAmount; }
    public void setSpentAmount(double spentAmount) { this.spentAmount = spentAmount; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public List<TripItem> getItems() { return items; }
    public void setItems(List<TripItem> items) { this.items = items; }
    
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    
    public double getRemainingBudget() {
        return budget - spentAmount;
    }
    
    public int getDurationDays() {
        if (startDate == null || endDate == null) return 0;
        return (int) (endDate.toEpochDay() - startDate.toEpochDay()) + 1;
    }
    
    public void addItem(TripItem item) {
        this.items.add(item);
        this.spentAmount += item.getCost();
    }
}
