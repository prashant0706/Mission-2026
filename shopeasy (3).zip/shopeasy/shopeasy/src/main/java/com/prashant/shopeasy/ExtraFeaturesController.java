package com.prashant.shopeasy;

import com.prashant.shopeasy.model.*;
import com.prashant.shopeasy.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/travel")
public class ExtraFeaturesController {

    @Autowired private ExtraService extraService;
    @Autowired private UserService userService;

    // ==================== OFFERS & COUPONS ====================
    @GetMapping("/offers")
    public String offers(Model model) {
        model.addAttribute("coupons", extraService.getActiveCoupons());
        return "travel/offers";
    }

    @PostMapping("/apply-coupon")
    @ResponseBody
    public String applyCoupon(@RequestParam String code, 
                              @RequestParam double amount,
                              @RequestParam String bookingType) {
        double discount = extraService.applyCoupon(code, amount, bookingType);
        if (discount > 0) {
            return "{\"success\": true, \"discount\": " + discount + ", \"message\": \"Coupon applied!\"}";
        }
        return "{\"success\": false, \"discount\": 0, \"message\": \"Invalid or expired coupon\"}";
    }

    // ==================== REVIEWS ====================
    @GetMapping("/reviews")
    public String reviews(@RequestParam(required = false) String type, Model model) {
        if (type != null && !type.isEmpty()) {
            model.addAttribute("reviews", extraService.getReviewsByType(type));
        } else {
            model.addAttribute("reviews", extraService.getAllReviews());
        }
        model.addAttribute("averageRating", extraService.getAverageRating());
        model.addAttribute("filterType", type);
        return "travel/reviews";
    }

    @PostMapping("/reviews/submit")
    public String submitReview(@RequestParam String title,
                               @RequestParam String comment,
                               @RequestParam int rating,
                               @RequestParam String bookingType,
                               @RequestParam(defaultValue = "false") boolean recommended,
                               HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        
        Review review = new Review();
        review.setUserId(user != null ? user.getId() : 0);
        review.setUserName(user != null ? user.getName() : "Anonymous");
        review.setBookingType(bookingType);
        review.setRating(rating);
        review.setTitle(title);
        review.setComment(comment);
        review.setRecommended(recommended);
        
        extraService.addReview(review);
        return "redirect:/travel/reviews";
    }

    // ==================== CONTACT US ====================
    @GetMapping("/contact")
    public String contactPage(Model model) {
        return "travel/contact";
    }

    @PostMapping("/contact/submit")
    public String submitContact(@RequestParam String name,
                               @RequestParam String email,
                               @RequestParam String phone,
                               @RequestParam String subject,
                               @RequestParam String category,
                               @RequestParam String message,
                               @RequestParam String priority,
                               @RequestParam(defaultValue = "false") boolean newsletter,
                               @RequestParam(required = false) MultipartFile attachment,
                               Model model) {
        ContactMessage contactMsg = new ContactMessage();
        contactMsg.setName(name);
        contactMsg.setEmail(email);
        contactMsg.setPhone(phone);
        contactMsg.setSubject(subject);
        contactMsg.setCategory(category);
        contactMsg.setMessage(message);
        contactMsg.setPriority(priority);
        contactMsg.setNewsletter(newsletter);
        
        if (attachment != null && !attachment.isEmpty()) {
            contactMsg.setAttachmentName(attachment.getOriginalFilename());
        }
        
        extraService.submitContactMessage(contactMsg);
        model.addAttribute("success", true);
        return "travel/contact";
    }

    // ==================== SEAT SELECTION (Drag & Drop Demo) ====================
    @GetMapping("/seat-selection/{bookingType}/{id}")
    public String seatSelection(@PathVariable String bookingType, @PathVariable int id, Model model) {
        model.addAttribute("bookingType", bookingType);
        model.addAttribute("transportId", id);
        return "travel/seat-selection";
    }

    // ==================== PROFILE SETTINGS (File Upload) ====================
    @GetMapping("/settings")
    public String settings(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        model.addAttribute("user", user);
        return "travel/settings";
    }

    @PostMapping("/settings/update")
    public String updateSettings(@RequestParam String name,
                                @RequestParam String phone,
                                @RequestParam String address,
                                @RequestParam(required = false) MultipartFile profilePicture,
                                @RequestParam(required = false) String theme,
                                @RequestParam(required = false) String language,
                                @RequestParam(defaultValue = "false") boolean emailNotifications,
                                @RequestParam(defaultValue = "false") boolean smsNotifications,
                                HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        // Update user details
        user.setName(name);
        user.setPhone(phone);
        user.setAddress(address);
        
        model.addAttribute("user", user);
        model.addAttribute("success", true);
        model.addAttribute("uploadedFileName", profilePicture != null && !profilePicture.isEmpty() ? profilePicture.getOriginalFilename() : null);
        return "travel/settings";
    }

    // ==================== HELP CENTER (iFrame Demo) ====================
    @GetMapping("/help")
    public String helpCenter(Model model) {
        return "travel/help";
    }

    @GetMapping("/help/faq")
    public String helpFaq() {
        return "travel/help-faq";
    }

    // ==================== NOTIFICATIONS (Dynamic Content) ====================
    @GetMapping("/notifications")
    public String notifications(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        return "travel/notifications";
    }

    @GetMapping("/api/notifications")
    @ResponseBody
    public String getNotifications() {
        // Simulated dynamic notifications
        return "[" +
            "{\"id\": 1, \"type\": \"success\", \"message\": \"Your booking is confirmed!\", \"time\": \"Just now\"}," +
            "{\"id\": 2, \"type\": \"info\", \"message\": \"New offer: Get 20% off on flights\", \"time\": \"5 min ago\"}," +
            "{\"id\": 3, \"type\": \"warning\", \"message\": \"Complete your profile for rewards\", \"time\": \"1 hour ago\"}" +
        "]";
    }
}
