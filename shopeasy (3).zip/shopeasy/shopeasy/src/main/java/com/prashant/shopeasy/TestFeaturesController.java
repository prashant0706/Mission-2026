package com.prashant.shopeasy;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class TestFeaturesController {

    // Main test features page
    @GetMapping("/test-features")
    public String testFeatures(Model model) {
        return "test-features";
    }

    // Page for iframe content
    @GetMapping("/iframe-content")
    public String iframeContent() {
        return "iframe-content";
    }

    // Handle form submission
    @PostMapping("/test-form-submit")
    public String handleFormSubmit(@RequestParam String username,
                                   @RequestParam String dropdown,
                                   @RequestParam(required = false) String[] checkboxes,
                                   @RequestParam String radio,
                                   Model model) {
        model.addAttribute("formSubmitted", true);
        model.addAttribute("username", username);
        model.addAttribute("dropdown", dropdown);
        model.addAttribute("checkboxes", checkboxes != null ? String.join(", ", checkboxes) : "None");
        model.addAttribute("radio", radio);
        return "test-features";
    }

    // Handle file upload
    @PostMapping("/test-file-upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file, Model model) {
        model.addAttribute("fileUploaded", true);
        model.addAttribute("fileName", file.getOriginalFilename());
        model.addAttribute("fileSize", file.getSize());
        return "test-features";
    }

    // New window target page
    @GetMapping("/new-window")
    public String newWindow() {
        return "new-window";
    }

    // Page with dynamic content (AJAX simulation)
    @GetMapping("/dynamic-content")
    @ResponseBody
    public String getDynamicContent() {
        // Simulate delay
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return "<div class='loaded-content'>✅ Content loaded after 2 seconds!</div>";
    }
}
