package com.prashant.shopeasy.model;

public class Review {
    
    private int id;
    private int userId;
    private String userName;
    private int bookingId;
    private String bookingType; // FLIGHT or BUS
    private int rating; // 1-5
    private String title;
    private String comment;
    private String travelDate;
    private boolean recommended;
    private String createdAt;
    
    public Review() {}
    
    public Review(int id, int userId, String userName, int bookingId, String bookingType,
                  int rating, String title, String comment, String travelDate, boolean recommended) {
        this.id = id;
        this.userId = userId;
        this.userName = userName;
        this.bookingId = bookingId;
        this.bookingType = bookingType;
        this.rating = rating;
        this.title = title;
        this.comment = comment;
        this.travelDate = travelDate;
        this.recommended = recommended;
        this.createdAt = java.time.LocalDateTime.now().toString();
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
    
    public int getBookingId() { return bookingId; }
    public void setBookingId(int bookingId) { this.bookingId = bookingId; }
    
    public String getBookingType() { return bookingType; }
    public void setBookingType(String bookingType) { this.bookingType = bookingType; }
    
    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    
    public String getTravelDate() { return travelDate; }
    public void setTravelDate(String travelDate) { this.travelDate = travelDate; }
    
    public boolean isRecommended() { return recommended; }
    public void setRecommended(boolean recommended) { this.recommended = recommended; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
