package com.prashant.shopeasy.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Bus {
    
    private int id;
    private String busNumber;
    private String operatorName;
    private String busType; // AC Sleeper, Non-AC, Volvo, etc.
    private String source;
    private String destination;
    private LocalDate departureDate;
    private LocalTime departureTime;
    private LocalTime arrivalTime;
    private double price;
    private int availableSeats;
    private String amenities; // WiFi, Charging, Blanket
    
    public Bus() {}
    
    public Bus(int id, String busNumber, String operatorName, String busType, String source, 
               String destination, LocalDate departureDate, LocalTime departureTime, 
               LocalTime arrivalTime, double price, int availableSeats, String amenities) {
        this.id = id;
        this.busNumber = busNumber;
        this.operatorName = operatorName;
        this.busType = busType;
        this.source = source;
        this.destination = destination;
        this.departureDate = departureDate;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.price = price;
        this.availableSeats = availableSeats;
        this.amenities = amenities;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getBusNumber() { return busNumber; }
    public void setBusNumber(String busNumber) { this.busNumber = busNumber; }
    
    public String getOperatorName() { return operatorName; }
    public void setOperatorName(String operatorName) { this.operatorName = operatorName; }
    
    public String getBusType() { return busType; }
    public void setBusType(String busType) { this.busType = busType; }
    
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    
    public LocalDate getDepartureDate() { return departureDate; }
    public void setDepartureDate(LocalDate departureDate) { this.departureDate = departureDate; }
    
    public LocalTime getDepartureTime() { return departureTime; }
    public void setDepartureTime(LocalTime departureTime) { this.departureTime = departureTime; }
    
    public LocalTime getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(LocalTime arrivalTime) { this.arrivalTime = arrivalTime; }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    
    public int getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(int availableSeats) { this.availableSeats = availableSeats; }
    
    public String getAmenities() { return amenities; }
    public void setAmenities(String amenities) { this.amenities = amenities; }
    
    public String getDuration() {
        int depMinutes = departureTime.getHour() * 60 + departureTime.getMinute();
        int arrMinutes = arrivalTime.getHour() * 60 + arrivalTime.getMinute();
        int diff = arrMinutes - depMinutes;
        if (diff < 0) diff += 24 * 60;
        return (diff / 60) + "h " + (diff % 60) + "m";
    }
}
