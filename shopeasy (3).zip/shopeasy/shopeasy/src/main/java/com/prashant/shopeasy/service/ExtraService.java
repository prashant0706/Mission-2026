package com.prashant.shopeasy.service;

import com.prashant.shopeasy.model.Review;
import com.prashant.shopeasy.model.Coupon;
import com.prashant.shopeasy.model.ContactMessage;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExtraService {
    
    private List<Review> reviews = new ArrayList<>();
    private List<Coupon> coupons = new ArrayList<>();
    private List<ContactMessage> contactMessages = new ArrayList<>();
    private int nextReviewId = 1;
    private int nextMessageId = 1;
    
    public ExtraService() {
        initializeCoupons();
        initializeSampleReviews();
    }
    
    private void initializeCoupons() {
        coupons.add(new Coupon(1, "FIRST50", "50% off on first booking", 50, 500, 1000, "2025-01-01", "2025-12-31", true, "ALL"));
        coupons.add(new Coupon(2, "FLY20", "20% off on flights", 20, 1000, 2000, "2025-01-01", "2025-06-30", true, "FLIGHT"));
        coupons.add(new Coupon(3, "BUS15", "15% off on bus bookings", 15, 300, 500, "2025-01-01", "2025-03-31", true, "BUS"));
        coupons.add(new Coupon(4, "SUMMER25", "Summer special 25% off", 25, 750, 1500, "2025-04-01", "2025-06-30", true, "ALL"));
        coupons.add(new Coupon(5, "WEEKEND10", "Weekend getaway 10% off", 10, 500, 1000, "2025-01-01", "2025-12-31", true, "ALL"));
        coupons.add(new Coupon(6, "EXPIRED20", "Expired coupon", 20, 400, 800, "2024-01-01", "2024-12-31", false, "ALL"));
    }
    
    private void initializeSampleReviews() {
        reviews.add(new Review(nextReviewId++, 1, "Prashant Rathod", 0, "FLIGHT", 5, "Amazing experience!", "The flight was on time and service was excellent. Would definitely book again!", "2025-01-15", true));
        reviews.add(new Review(nextReviewId++, 1, "Test User", 0, "BUS", 4, "Comfortable journey", "AC was good, driver was experienced. Minor delay but overall good.", "2025-01-10", true));
        reviews.add(new Review(nextReviewId++, 1, "Rahul Sharma", 0, "FLIGHT", 3, "Average", "Flight was delayed by 30 minutes. Staff could be more helpful.", "2025-01-05", false));
    }
    
    // Reviews
    public Review addReview(Review review) {
        review.setId(nextReviewId++);
        review.setCreatedAt(java.time.LocalDateTime.now().toString());
        reviews.add(review);
        return review;
    }
    
    public List<Review> getAllReviews() {
        return reviews;
    }
    
    public List<Review> getReviewsByType(String type) {
        return reviews.stream().filter(r -> r.getBookingType().equals(type)).collect(Collectors.toList());
    }
    
    public double getAverageRating() {
        if (reviews.isEmpty()) return 0;
        return reviews.stream().mapToInt(Review::getRating).average().orElse(0);
    }
    
    // Coupons
    public List<Coupon> getAllCoupons() {
        return coupons;
    }
    
    public List<Coupon> getActiveCoupons() {
        return coupons.stream().filter(Coupon::isActive).collect(Collectors.toList());
    }
    
    public Coupon getCouponByCode(String code) {
        return coupons.stream().filter(c -> c.getCode().equalsIgnoreCase(code)).findFirst().orElse(null);
    }
    
    public double applyCoupon(String code, double amount, String bookingType) {
        Coupon coupon = getCouponByCode(code);
        if (coupon == null || !coupon.isActive()) return 0;
        if (amount < coupon.getMinBookingAmount()) return 0;
        if (!coupon.getApplicableFor().equals("ALL") && !coupon.getApplicableFor().equals(bookingType)) return 0;
        
        double discount = (amount * coupon.getDiscountPercent()) / 100;
        return Math.min(discount, coupon.getMaxDiscount());
    }
    
    // Contact Messages
    public ContactMessage submitContactMessage(ContactMessage message) {
        message.setId(nextMessageId++);
        message.setCreatedAt(java.time.LocalDateTime.now().toString());
        message.setStatus("NEW");
        contactMessages.add(message);
        return message;
    }
    
    public List<ContactMessage> getAllContactMessages() {
        return contactMessages;
    }
    
    public ContactMessage getMessageById(int id) {
        return contactMessages.stream().filter(m -> m.getId() == id).findFirst().orElse(null);
    }
    
    public void updateMessageStatus(int id, String status) {
        ContactMessage msg = getMessageById(id);
        if (msg != null) msg.setStatus(status);
    }
}
