package com.prashant.shopeasy;

import com.prashant.shopeasy.model.*;
import com.prashant.shopeasy.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired private FlightService flightService;
    @Autowired private BusService busService;
    @Autowired private BookingService bookingService;
    @Autowired private TripService tripService;
    @Autowired private WalletService walletService;
    @Autowired private UserService userService;

    // Admin credentials (hardcoded for demo)
    private static final String ADMIN_EMAIL = "admin@traveleasy.com";
    private static final String ADMIN_PASSWORD = "admin123";

    @GetMapping("/login")
    public String adminLoginPage(Model model) {
        model.addAttribute("error", null);
        return "admin/login";
    }

    @PostMapping("/login")
    public String adminLogin(@RequestParam String email,
                            @RequestParam String password,
                            HttpSession session, Model model) {
        if (ADMIN_EMAIL.equals(email) && ADMIN_PASSWORD.equals(password)) {
            session.setAttribute("isAdmin", true);
            return "redirect:/admin/dashboard";
        }
        model.addAttribute("error", "Invalid admin credentials");
        return "admin/login";
    }

    @GetMapping("/logout")
    public String adminLogout(HttpSession session) {
        session.removeAttribute("isAdmin");
        return "redirect:/admin/login";
    }

    private boolean checkAdmin(HttpSession session) {
        Boolean isAdmin = (Boolean) session.getAttribute("isAdmin");
        return isAdmin != null && isAdmin;
    }

    // ==================== DASHBOARD ====================
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (!checkAdmin(session)) return "redirect:/admin/login";

        // Statistics
        model.addAttribute("totalBookings", bookingService.getTotalBookingsCount());
        model.addAttribute("confirmedBookings", bookingService.getConfirmedBookingsCount());
        model.addAttribute("cancelledBookings", bookingService.getCancelledBookingsCount());
        model.addAttribute("flightBookings", bookingService.getFlightBookingsCount());
        model.addAttribute("busBookings", bookingService.getBusBookingsCount());
        model.addAttribute("totalRevenue", bookingService.getTotalRevenue());
        model.addAttribute("totalUsers", userService.getAllUsers().size());
        model.addAttribute("totalTrips", tripService.getTotalTripsCount());
        
        // Recent activity
        model.addAttribute("recentBookings", bookingService.getAllBookings());
        model.addAttribute("recentTransactions", walletService.getAllTransactions());
        
        return "admin/dashboard";
    }

    // ==================== BOOKINGS MANAGEMENT ====================
    @GetMapping("/bookings")
    public String allBookings(@RequestParam(required = false) String type,
                              @RequestParam(required = false) String status,
                              HttpSession session, Model model) {
        if (!checkAdmin(session)) return "redirect:/admin/login";
        
        List<Booking> bookings;
        if (type != null && !type.isEmpty()) {
            bookings = bookingService.getBookingsByType(type);
        } else if (status != null && !status.isEmpty()) {
            bookings = bookingService.getBookingsByStatus(status);
        } else {
            bookings = bookingService.getAllBookings();
        }
        
        model.addAttribute("bookings", bookings);
        model.addAttribute("filterType", type);
        model.addAttribute("filterStatus", status);
        return "admin/bookings";
    }

    @GetMapping("/bookings/{id}")
    public String bookingDetails(@PathVariable int id, HttpSession session, Model model) {
        if (!checkAdmin(session)) return "redirect:/admin/login";
        
        Booking booking = bookingService.getBookingById(id);
        if (booking == null) return "redirect:/admin/bookings";
        
        model.addAttribute("booking", booking);
        return "admin/booking-details";
    }

    // ==================== USERS MANAGEMENT ====================
    @GetMapping("/users")
    public String allUsers(HttpSession session, Model model) {
        if (!checkAdmin(session)) return "redirect:/admin/login";
        
        List<User> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "admin/users";
    }

    @GetMapping("/users/{id}")
    public String userDetails(@PathVariable int id, HttpSession session, Model model) {
        if (!checkAdmin(session)) return "redirect:/admin/login";
        
        // Find user - since we don't have getUserById, we'll search
        List<User> users = userService.getAllUsers();
        User user = users.stream().filter(u -> u.getId() == id).findFirst().orElse(null);
        if (user == null) return "redirect:/admin/users";
        
        model.addAttribute("user", user);
        model.addAttribute("userBookings", bookingService.getBookingsByUserId(id));
        model.addAttribute("userTrips", tripService.getTripsByUserId(id));
        model.addAttribute("walletBalance", walletService.getBalance(id));
        model.addAttribute("userTransactions", walletService.getTransactions(id));
        return "admin/user-details";
    }

    // ==================== FLIGHTS MANAGEMENT ====================
    @GetMapping("/flights")
    public String allFlights(HttpSession session, Model model) {
        if (!checkAdmin(session)) return "redirect:/admin/login";
        
        model.addAttribute("flights", flightService.getAllFlights());
        return "admin/flights";
    }

    // ==================== BUSES MANAGEMENT ====================
    @GetMapping("/buses")
    public String allBuses(HttpSession session, Model model) {
        if (!checkAdmin(session)) return "redirect:/admin/login";
        
        model.addAttribute("buses", busService.getAllBuses());
        return "admin/buses";
    }

    // ==================== REPORTS ====================
    @GetMapping("/reports")
    public String reports(HttpSession session, Model model) {
        if (!checkAdmin(session)) return "redirect:/admin/login";
        
        model.addAttribute("totalRevenue", bookingService.getTotalRevenue());
        model.addAttribute("flightRevenue", calculateFlightRevenue());
        model.addAttribute("busRevenue", calculateBusRevenue());
        model.addAttribute("totalBookings", bookingService.getTotalBookingsCount());
        model.addAttribute("totalTrips", tripService.getTotalTripsCount());
        model.addAttribute("tripBudget", tripService.getTotalBudget());
        model.addAttribute("tripSpent", tripService.getTotalSpent());
        
        return "admin/reports";
    }

    private double calculateFlightRevenue() {
        return bookingService.getBookingsByType("FLIGHT").stream()
            .filter(b -> b.getStatus().equals("CONFIRMED"))
            .mapToDouble(Booking::getTotalAmount).sum();
    }

    private double calculateBusRevenue() {
        return bookingService.getBookingsByType("BUS").stream()
            .filter(b -> b.getStatus().equals("CONFIRMED"))
            .mapToDouble(Booking::getTotalAmount).sum();
    }
}
