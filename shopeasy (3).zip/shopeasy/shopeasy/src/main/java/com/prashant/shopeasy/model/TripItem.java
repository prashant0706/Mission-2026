package com.prashant.shopeasy.model;

import java.time.LocalDate;

public class TripItem {
    
    private int id;
    private int tripId;
    private String itemType; // TRANSPORT, ACCOMMODATION, FOOD, ACTIVITY, OTHER
    private String title;
    private String description;
    private LocalDate date;
    private String time;
    private double cost;
    private String status; // PLANNED, BOOKED, COMPLETED
    private String bookingReference;
    
    public TripItem() {
        this.status = "PLANNED";
    }
    
    public TripItem(int id, int tripId, String itemType, String title, String description,
                    LocalDate date, String time, double cost) {
        this.id = id;
        this.tripId = tripId;
        this.itemType = itemType;
        this.title = title;
        this.description = description;
        this.date = date;
        this.time = time;
        this.cost = cost;
        this.status = "PLANNED";
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getTripId() { return tripId; }
    public void setTripId(int tripId) { this.tripId = tripId; }
    
    public String getItemType() { return itemType; }
    public void setItemType(String itemType) { this.itemType = itemType; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
    
    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
    
    public double getCost() { return cost; }
    public void setCost(double cost) { this.cost = cost; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public String getBookingReference() { return bookingReference; }
    public void setBookingReference(String bookingReference) { this.bookingReference = bookingReference; }
}
