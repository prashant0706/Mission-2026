package com.prashant.shopeasy.service;

import com.prashant.shopeasy.model.User;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {
    
    private List<User> users = new ArrayList<>();
    private int nextId = 1;
    
    public UserService() {
        // Add a default user for testing
        users.add(new User(nextId++, "Test User", "test@example.com", "password123", "9876543210", "123 Test Street, Pune"));
    }
    
    public User register(String name, String email, String password, String phone, String address) {
        // Check if email already exists
        for (User user : users) {
            if (user.getEmail().equalsIgnoreCase(email)) {
                return null; // Email already exists
            }
        }
        
        User newUser = new User(nextId++, name, email, password, phone, address);
        users.add(newUser);
        return newUser;
    }
    
    public User login(String email, String password) {
        for (User user : users) {
            if (user.getEmail().equalsIgnoreCase(email) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null; // Invalid credentials
    }
    
    public User findByEmail(String email) {
        for (User user : users) {
            if (user.getEmail().equalsIgnoreCase(email)) {
                return user;
            }
        }
        return null;
    }
    
    public List<User> getAllUsers() {
        return users;
    }
}
