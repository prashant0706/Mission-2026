package com.prashant.shopeasy;

import com.prashant.shopeasy.model.*;
import com.prashant.shopeasy.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
@RequestMapping("/travel")
public class TravelController {

    @Autowired private FlightService flightService;
    @Autowired private BusService busService;
    @Autowired private BookingService bookingService;
    @Autowired private TripService tripService;
    @Autowired private WalletService walletService;
    @Autowired private UserService userService;

    // Travel Home/Dashboard
    @GetMapping("")
    public String travelHome(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user != null) {
            model.addAttribute("user", user);
            model.addAttribute("walletBalance", walletService.getBalance(user.getId()));
            model.addAttribute("recentBookings", bookingService.getBookingsByUserId(user.getId()));
            model.addAttribute("upcomingTrips", tripService.getTripsByUserId(user.getId()));
        }
        model.addAttribute("cities", flightService.getAllCities());
        return "travel/home";
    }

    // ==================== FLIGHTS ====================
    @GetMapping("/flights")
    public String searchFlights(@RequestParam(required = false) String source,
                                @RequestParam(required = false) String destination,
                                @RequestParam(required = false) String date,
                                Model model) {
        List<Flight> flights;
        if (source != null && destination != null && date != null && !date.isEmpty()) {
            LocalDate searchDate = LocalDate.parse(date);
            flights = flightService.searchFlights(source, destination, searchDate);
            model.addAttribute("searchPerformed", true);
        } else {
            flights = flightService.getAllFlights();
        }
        model.addAttribute("flights", flights);
        model.addAttribute("cities", flightService.getAllCities());
        model.addAttribute("airlines", flightService.getAllAirlines());
        model.addAttribute("source", source);
        model.addAttribute("destination", destination);
        model.addAttribute("date", date);
        return "travel/flights";
    }

    @GetMapping("/flights/book/{id}")
    public String showFlightBookingForm(@PathVariable int id, HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login?redirect=/travel/flights/book/" + id;
        
        Flight flight = flightService.getFlightById(id);
        if (flight == null) return "redirect:/travel/flights";
        
        model.addAttribute("flight", flight);
        model.addAttribute("user", user);
        model.addAttribute("walletBalance", walletService.getBalance(user.getId()));
        return "travel/book-flight";
    }

    @PostMapping("/flights/book")
    public String bookFlight(@RequestParam int flightId,
                            @RequestParam int passengers,
                            @RequestParam String passengerNames,
                            @RequestParam String paymentMethod,
                            HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        Flight flight = flightService.getFlightById(flightId);
        if (flight == null || flight.getAvailableSeats() < passengers) {
            model.addAttribute("error", "Flight not available or insufficient seats");
            return "redirect:/travel/flights";
        }
        
        double totalAmount = flight.getPrice() * passengers;
        
        // Check wallet balance if paying via wallet
        if ("WALLET".equals(paymentMethod) && walletService.getBalance(user.getId()) < totalAmount) {
            model.addAttribute("error", "Insufficient wallet balance");
            return "redirect:/travel/flights/book/" + flightId;
        }
        
        // Create booking
        Booking booking = new Booking();
        booking.setBookingType("FLIGHT");
        booking.setUserId(user.getId());
        booking.setUserName(user.getName());
        booking.setUserEmail(user.getEmail());
        booking.setTransportId(flightId);
        booking.setTransportDetails(flight.getAirline() + " " + flight.getFlightNumber());
        booking.setSource(flight.getSource());
        booking.setDestination(flight.getDestination());
        booking.setTravelDate(flight.getDepartureDate().toString());
        booking.setPassengers(passengers);
        booking.setTotalAmount(totalAmount);
        booking.setPassengerNames(passengerNames);
        
        booking = bookingService.createBooking(booking);
        flightService.bookSeats(flightId, passengers);
        
        // Deduct from wallet if wallet payment
        if ("WALLET".equals(paymentMethod)) {
            walletService.deductMoney(user.getId(), totalAmount, 
                "Flight booking: " + flight.getFlightNumber(), "BOOKING", booking.getBookingReference());
        }
        
        return "redirect:/travel/booking-confirmation/" + booking.getId();
    }

    // ==================== BUSES ====================
    @GetMapping("/buses")
    public String searchBuses(@RequestParam(required = false) String source,
                             @RequestParam(required = false) String destination,
                             @RequestParam(required = false) String date,
                             Model model) {
        List<Bus> buses;
        if (source != null && destination != null && date != null && !date.isEmpty()) {
            LocalDate searchDate = LocalDate.parse(date);
            buses = busService.searchBuses(source, destination, searchDate);
            model.addAttribute("searchPerformed", true);
        } else {
            buses = busService.getAllBuses();
        }
        model.addAttribute("buses", buses);
        model.addAttribute("cities", busService.getAllCities());
        model.addAttribute("operators", busService.getAllOperators());
        model.addAttribute("busTypes", busService.getAllBusTypes());
        model.addAttribute("source", source);
        model.addAttribute("destination", destination);
        model.addAttribute("date", date);
        return "travel/buses";
    }

    @GetMapping("/buses/book/{id}")
    public String showBusBookingForm(@PathVariable int id, HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login?redirect=/travel/buses/book/" + id;
        
        Bus bus = busService.getBusById(id);
        if (bus == null) return "redirect:/travel/buses";
        
        model.addAttribute("bus", bus);
        model.addAttribute("user", user);
        model.addAttribute("walletBalance", walletService.getBalance(user.getId()));
        return "travel/book-bus";
    }

    @PostMapping("/buses/book")
    public String bookBus(@RequestParam int busId,
                         @RequestParam int passengers,
                         @RequestParam String passengerNames,
                         @RequestParam String paymentMethod,
                         HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        Bus bus = busService.getBusById(busId);
        if (bus == null || bus.getAvailableSeats() < passengers) {
            return "redirect:/travel/buses";
        }
        
        double totalAmount = bus.getPrice() * passengers;
        
        if ("WALLET".equals(paymentMethod) && walletService.getBalance(user.getId()) < totalAmount) {
            return "redirect:/travel/buses/book/" + busId;
        }
        
        Booking booking = new Booking();
        booking.setBookingType("BUS");
        booking.setUserId(user.getId());
        booking.setUserName(user.getName());
        booking.setUserEmail(user.getEmail());
        booking.setTransportId(busId);
        booking.setTransportDetails(bus.getOperatorName() + " - " + bus.getBusType());
        booking.setSource(bus.getSource());
        booking.setDestination(bus.getDestination());
        booking.setTravelDate(bus.getDepartureDate().toString());
        booking.setPassengers(passengers);
        booking.setTotalAmount(totalAmount);
        booking.setPassengerNames(passengerNames);
        
        booking = bookingService.createBooking(booking);
        busService.bookSeats(busId, passengers);
        
        if ("WALLET".equals(paymentMethod)) {
            walletService.deductMoney(user.getId(), totalAmount, 
                "Bus booking: " + bus.getOperatorName(), "BOOKING", booking.getBookingReference());
        }
        
        return "redirect:/travel/booking-confirmation/" + booking.getId();
    }

    // ==================== BOOKINGS ====================
    @GetMapping("/booking-confirmation/{id}")
    public String bookingConfirmation(@PathVariable int id, Model model) {
        Booking booking = bookingService.getBookingById(id);
        if (booking == null) return "redirect:/travel";
        model.addAttribute("booking", booking);
        return "travel/booking-confirmation";
    }

    @GetMapping("/my-bookings")
    public String myBookings(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        model.addAttribute("bookings", bookingService.getBookingsByUserId(user.getId()));
        return "travel/my-bookings";
    }

    @GetMapping("/cancel-booking/{id}")
    public String cancelBooking(@PathVariable int id, HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        Booking booking = bookingService.getBookingById(id);
        if (booking != null && booking.getUserId() == user.getId()) {
            bookingService.cancelBooking(id);
            // Refund to wallet
            walletService.refund(user.getId(), booking.getTotalAmount() * 0.8, 
                "Refund for cancelled booking", booking.getBookingReference());
        }
        return "redirect:/travel/my-bookings";
    }

    // ==================== WALLET ====================
    @GetMapping("/wallet")
    public String wallet(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        model.addAttribute("balance", walletService.getBalance(user.getId()));
        model.addAttribute("transactions", walletService.getTransactions(user.getId()));
        model.addAttribute("totalCredits", walletService.getTotalCredits(user.getId()));
        model.addAttribute("totalDebits", walletService.getTotalDebits(user.getId()));
        return "travel/wallet";
    }

    @PostMapping("/wallet/add")
    public String addMoney(@RequestParam double amount, HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        walletService.addMoney(user.getId(), amount, "Wallet recharge");
        return "redirect:/travel/wallet";
    }

    // ==================== TRIP PLANNER ====================
    @GetMapping("/trips")
    public String myTrips(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        model.addAttribute("trips", tripService.getTripsByUserId(user.getId()));
        return "travel/my-trips";
    }

    @GetMapping("/trips/new")
    public String newTripForm(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        return "travel/new-trip";
    }

    @PostMapping("/trips/create")
    public String createTrip(@RequestParam String tripName,
                            @RequestParam String destination,
                            @RequestParam String startDate,
                            @RequestParam String endDate,
                            @RequestParam double budget,
                            @RequestParam(required = false) String notes,
                            HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        Trip trip = new Trip();
        trip.setUserId(user.getId());
        trip.setTripName(tripName);
        trip.setDestination(destination);
        trip.setStartDate(LocalDate.parse(startDate));
        trip.setEndDate(LocalDate.parse(endDate));
        trip.setBudget(budget);
        trip.setNotes(notes);
        
        trip = tripService.createTrip(trip);
        return "redirect:/travel/trips/" + trip.getId();
    }

    @GetMapping("/trips/{id}")
    public String tripDetails(@PathVariable int id, HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        Trip trip = tripService.getTripById(id);
        if (trip == null || trip.getUserId() != user.getId()) return "redirect:/travel/trips";
        
        model.addAttribute("trip", trip);
        return "travel/trip-details";
    }

    @PostMapping("/trips/{id}/add-item")
    public String addTripItem(@PathVariable int id,
                             @RequestParam String itemType,
                             @RequestParam String title,
                             @RequestParam String description,
                             @RequestParam String date,
                             @RequestParam(required = false) String time,
                             @RequestParam double cost,
                             HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        TripItem item = new TripItem();
        item.setItemType(itemType);
        item.setTitle(title);
        item.setDescription(description);
        item.setDate(LocalDate.parse(date));
        item.setTime(time);
        item.setCost(cost);
        
        tripService.addItemToTrip(id, item);
        return "redirect:/travel/trips/" + id;
    }

    @GetMapping("/trips/{tripId}/remove-item/{itemId}")
    public String removeTripItem(@PathVariable int tripId, @PathVariable int itemId, HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";
        
        tripService.removeItemFromTrip(tripId, itemId);
        return "redirect:/travel/trips/" + tripId;
    }
}
