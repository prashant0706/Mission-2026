package com.prashant.shopeasy.service;

import com.prashant.shopeasy.model.Transaction;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class WalletService {
    
    private Map<Integer, Double> walletBalances = new HashMap<>();
    private List<Transaction> transactions = new ArrayList<>();
    private int nextTransactionId = 1;
    
    public WalletService() {
        // Initialize with some default balance for test user
        walletBalances.put(1, 10000.0);
    }
    
    public double getBalance(int userId) {
        return walletBalances.getOrDefault(userId, 0.0);
    }
    
    public boolean addMoney(int userId, double amount, String description) {
        if (amount <= 0) return false;
        
        double currentBalance = getBalance(userId);
        walletBalances.put(userId, currentBalance + amount);
        
        Transaction transaction = new Transaction(
            nextTransactionId++, userId, "CREDIT", amount, description, "WALLET_RECHARGE", "WLT" + System.currentTimeMillis()
        );
        transactions.add(transaction);
        return true;
    }
    
    public boolean deductMoney(int userId, double amount, String description, String category, String referenceId) {
        double currentBalance = getBalance(userId);
        if (amount <= 0 || currentBalance < amount) return false;
        
        walletBalances.put(userId, currentBalance - amount);
        
        Transaction transaction = new Transaction(
            nextTransactionId++, userId, "DEBIT", amount, description, category, referenceId
        );
        transactions.add(transaction);
        return true;
    }
    
    public boolean refund(int userId, double amount, String description, String referenceId) {
        if (amount <= 0) return false;
        
        double currentBalance = getBalance(userId);
        walletBalances.put(userId, currentBalance + amount);
        
        Transaction transaction = new Transaction(
            nextTransactionId++, userId, "CREDIT", amount, description, "REFUND", referenceId
        );
        transactions.add(transaction);
        return true;
    }
    
    public List<Transaction> getTransactions(int userId) {
        return transactions.stream()
            .filter(t -> t.getUserId() == userId)
            .sorted((a, b) -> b.getTransactionDate().compareTo(a.getTransactionDate()))
            .collect(Collectors.toList());
    }
    
    public List<Transaction> getAllTransactions() {
        return transactions.stream()
            .sorted((a, b) -> b.getTransactionDate().compareTo(a.getTransactionDate()))
            .collect(Collectors.toList());
    }
    
    public double getTotalCredits(int userId) {
        return transactions.stream()
            .filter(t -> t.getUserId() == userId && t.getType().equals("CREDIT"))
            .mapToDouble(Transaction::getAmount)
            .sum();
    }
    
    public double getTotalDebits(int userId) {
        return transactions.stream()
            .filter(t -> t.getUserId() == userId && t.getType().equals("DEBIT"))
            .mapToDouble(Transaction::getAmount)
            .sum();
    }
    
    public double getSystemTotalRevenue() {
        return transactions.stream()
            .filter(t -> t.getType().equals("DEBIT") && t.getCategory().equals("BOOKING"))
            .mapToDouble(Transaction::getAmount)
            .sum();
    }
}
