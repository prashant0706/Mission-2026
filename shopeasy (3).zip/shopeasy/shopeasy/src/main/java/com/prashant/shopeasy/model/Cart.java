package com.prashant.shopeasy.model;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    
    private List<CartItem> items = new ArrayList<>();
    
    public void addProduct(Product product) {
        for (CartItem item : items) {
            if (item.getProduct().getId() == product.getId()) {
                item.setQuantity(item.getQuantity() + 1);
                return;
            }
        }
        items.add(new CartItem(product, 1));
    }
    
    public void removeProduct(int productId) {
        items.removeIf(item -> item.getProduct().getId() == productId);
    }
    
    public void updateQuantity(int productId, int quantity) {
        if (quantity <= 0) {
            removeProduct(productId);
            return;
        }
        
        for (CartItem item : items) {
            if (item.getProduct().getId() == productId) {
                item.setQuantity(quantity);
                return;
            }
        }
    }
    
    public void increaseQuantity(int productId) {
        for (CartItem item : items) {
            if (item.getProduct().getId() == productId) {
                item.setQuantity(item.getQuantity() + 1);
                return;
            }
        }
    }
    
    public void decreaseQuantity(int productId) {
        for (CartItem item : items) {
            if (item.getProduct().getId() == productId) {
                int newQty = item.getQuantity() - 1;
                if (newQty <= 0) {
                    removeProduct(productId);
                } else {
                    item.setQuantity(newQty);
                }
                return;
            }
        }
    }
    
    public List<CartItem> getItems() {
        return items;
    }
    
    public double getTotalPrice() {
        double total = 0;
        for (CartItem item : items) {
            total += item.getTotalPrice();
        }
        return total;
    }
    
    public int getTotalItems() {
        int count = 0;
        for (CartItem item : items) {
            count += item.getQuantity();
        }
        return count;
    }
    
    public void clear() {
        items.clear();
    }
}