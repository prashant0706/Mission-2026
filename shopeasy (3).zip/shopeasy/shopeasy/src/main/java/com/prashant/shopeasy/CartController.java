package com.prashant.shopeasy;

import com.prashant.shopeasy.model.Cart;
import com.prashant.shopeasy.model.Product;
import com.prashant.shopeasy.service.ProductService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CartController {

    @Autowired
    private ProductService productService;

    private Cart getCart(HttpSession session) {
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }
        return cart;
    }

    @GetMapping("/cart")
    public String viewCart(HttpSession session, Model model) {
        Cart cart = getCart(session);
        model.addAttribute("cart", cart);
        return "cart";
    }

    @GetMapping("/cart/add/{productId}")
    public String addToCart(@PathVariable int productId, HttpSession session) {
        Product product = productService.getProductById(productId);
        if (product != null) {
            Cart cart = getCart(session);
            cart.addProduct(product);
        }
        return "redirect:/products";
    }

    @GetMapping("/cart/remove/{productId}")
    public String removeFromCart(@PathVariable int productId, HttpSession session) {
        Cart cart = getCart(session);
        cart.removeProduct(productId);
        return "redirect:/cart";
    }

    @PostMapping("/cart/update/{productId}")
    public String updateQuantity(@PathVariable int productId, 
                                 @RequestParam int quantity, 
                                 HttpSession session) {
        Cart cart = getCart(session);
        cart.updateQuantity(productId, quantity);
        return "redirect:/cart";
    }

    @GetMapping("/cart/increase/{productId}")
    public String increaseQuantity(@PathVariable int productId, HttpSession session) {
        Cart cart = getCart(session);
        cart.increaseQuantity(productId);
        return "redirect:/cart";
    }

    @GetMapping("/cart/decrease/{productId}")
    public String decreaseQuantity(@PathVariable int productId, HttpSession session) {
        Cart cart = getCart(session);
        cart.decreaseQuantity(productId);
        return "redirect:/cart";
    }
}