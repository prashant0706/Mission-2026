package com.prashant.shopeasy.model;

import java.time.LocalDateTime;

public class Transaction {
    
    private int id;
    private int userId;
    private String type; // CREDIT, DEBIT
    private double amount;
    private String description;
    private String category; // BOOKING, REFUND, WALLET_RECHARGE, CASHBACK
    private LocalDateTime transactionDate;
    private String referenceId;
    
    public Transaction() {
        this.transactionDate = LocalDateTime.now();
    }
    
    public Transaction(int id, int userId, String type, double amount, String description, 
                       String category, String referenceId) {
        this.id = id;
        this.userId = userId;
        this.type = type;
        this.amount = amount;
        this.description = description;
        this.category = category;
        this.referenceId = referenceId;
        this.transactionDate = LocalDateTime.now();
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    
    public LocalDateTime getTransactionDate() { return transactionDate; }
    public void setTransactionDate(LocalDateTime transactionDate) { this.transactionDate = transactionDate; }
    
    public String getReferenceId() { return referenceId; }
    public void setReferenceId(String referenceId) { this.referenceId = referenceId; }
}
