package com.prashant.shopeasy.service;

import com.prashant.shopeasy.model.Trip;
import com.prashant.shopeasy.model.TripItem;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TripService {
    
    private List<Trip> trips = new ArrayList<>();
    private int nextTripId = 1;
    private int nextItemId = 1;
    
    public Trip createTrip(Trip trip) {
        trip.setId(nextTripId++);
        trip.setStatus("PLANNING");
        trips.add(trip);
        return trip;
    }
    
    public Trip getTripById(int id) {
        return trips.stream().filter(t -> t.getId() == id).findFirst().orElse(null);
    }
    
    public List<Trip> getTripsByUserId(int userId) {
        return trips.stream().filter(t -> t.getUserId() == userId).collect(Collectors.toList());
    }
    
    public List<Trip> getAllTrips() {
        return trips;
    }
    
    public Trip updateTrip(Trip trip) {
        for (int i = 0; i < trips.size(); i++) {
            if (trips.get(i).getId() == trip.getId()) {
                trips.set(i, trip);
                return trip;
            }
        }
        return null;
    }
    
    public boolean deleteTrip(int tripId) {
        return trips.removeIf(t -> t.getId() == tripId);
    }
    
    public TripItem addItemToTrip(int tripId, TripItem item) {
        Trip trip = getTripById(tripId);
        if (trip != null) {
            item.setId(nextItemId++);
            item.setTripId(tripId);
            trip.addItem(item);
            return item;
        }
        return null;
    }
    
    public boolean removeItemFromTrip(int tripId, int itemId) {
        Trip trip = getTripById(tripId);
        if (trip != null) {
            TripItem item = trip.getItems().stream().filter(i -> i.getId() == itemId).findFirst().orElse(null);
            if (item != null) {
                trip.setSpentAmount(trip.getSpentAmount() - item.getCost());
                return trip.getItems().removeIf(i -> i.getId() == itemId);
            }
        }
        return false;
    }
    
    public void updateTripStatus(int tripId, String status) {
        Trip trip = getTripById(tripId);
        if (trip != null) {
            trip.setStatus(status);
        }
    }
    
    public List<Trip> getTripsByStatus(String status) {
        return trips.stream().filter(t -> t.getStatus().equals(status)).collect(Collectors.toList());
    }
    
    public int getTotalTripsCount() {
        return trips.size();
    }
    
    public double getTotalBudget() {
        return trips.stream().mapToDouble(Trip::getBudget).sum();
    }
    
    public double getTotalSpent() {
        return trips.stream().mapToDouble(Trip::getSpentAmount).sum();
    }
}
