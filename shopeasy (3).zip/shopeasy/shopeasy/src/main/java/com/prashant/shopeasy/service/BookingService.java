package com.prashant.shopeasy.service;

import com.prashant.shopeasy.model.Booking;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Service
public class BookingService {
    
    private List<Booking> bookings = new ArrayList<>();
    private int nextId = 1;
    private Random random = new Random();
    
    public Booking createBooking(Booking booking) {
        booking.setId(nextId++);
        booking.setBookingReference(generateBookingReference());
        booking.setBookingDate(LocalDateTime.now());
        booking.setStatus("CONFIRMED");
        bookings.add(booking);
        return booking;
    }
    
    private String generateBookingReference() {
        return "TRV" + System.currentTimeMillis() % 100000 + random.nextInt(1000);
    }
    
    public Booking getBookingById(int id) {
        return bookings.stream().filter(b -> b.getId() == id).findFirst().orElse(null);
    }
    
    public Booking getBookingByReference(String reference) {
        return bookings.stream().filter(b -> b.getBookingReference().equals(reference)).findFirst().orElse(null);
    }
    
    public List<Booking> getBookingsByUserId(int userId) {
        return bookings.stream().filter(b -> b.getUserId() == userId).collect(Collectors.toList());
    }
    
    public List<Booking> getBookingsByEmail(String email) {
        return bookings.stream().filter(b -> b.getUserEmail().equalsIgnoreCase(email)).collect(Collectors.toList());
    }
    
    public List<Booking> getAllBookings() {
        return bookings;
    }
    
    public List<Booking> getBookingsByType(String type) {
        return bookings.stream().filter(b -> b.getBookingType().equals(type)).collect(Collectors.toList());
    }
    
    public List<Booking> getBookingsByStatus(String status) {
        return bookings.stream().filter(b -> b.getStatus().equals(status)).collect(Collectors.toList());
    }
    
    public boolean cancelBooking(int bookingId) {
        Booking booking = getBookingById(bookingId);
        if (booking != null && !booking.getStatus().equals("CANCELLED")) {
            booking.setStatus("CANCELLED");
            return true;
        }
        return false;
    }
    
    public double getTotalRevenue() {
        return bookings.stream()
            .filter(b -> b.getStatus().equals("CONFIRMED"))
            .mapToDouble(Booking::getTotalAmount)
            .sum();
    }
    
    public int getTotalBookingsCount() {
        return bookings.size();
    }
    
    public int getConfirmedBookingsCount() {
        return (int) bookings.stream().filter(b -> b.getStatus().equals("CONFIRMED")).count();
    }
    
    public int getCancelledBookingsCount() {
        return (int) bookings.stream().filter(b -> b.getStatus().equals("CANCELLED")).count();
    }
    
    public int getFlightBookingsCount() {
        return (int) bookings.stream().filter(b -> b.getBookingType().equals("FLIGHT")).count();
    }
    
    public int getBusBookingsCount() {
        return (int) bookings.stream().filter(b -> b.getBookingType().equals("BUS")).count();
    }
}
