package com.prashant.shopeasy.model;

public class ContactMessage {
    
    private int id;
    private String name;
    private String email;
    private String phone;
    private String subject;
    private String category; // BOOKING, REFUND, FEEDBACK, COMPLAINT, OTHER
    private String message;
    private String priority; // LOW, MEDIUM, HIGH
    private boolean newsletter;
    private String attachmentName;
    private String createdAt;
    private String status; // NEW, IN_PROGRESS, RESOLVED
    
    public ContactMessage() {
        this.status = "NEW";
        this.createdAt = java.time.LocalDateTime.now().toString();
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
    
    public boolean isNewsletter() { return newsletter; }
    public void setNewsletter(boolean newsletter) { this.newsletter = newsletter; }
    
    public String getAttachmentName() { return attachmentName; }
    public void setAttachmentName(String attachmentName) { this.attachmentName = attachmentName; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
