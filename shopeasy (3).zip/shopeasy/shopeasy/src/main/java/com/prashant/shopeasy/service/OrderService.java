package com.prashant.shopeasy.service;

import com.prashant.shopeasy.model.Cart;
import com.prashant.shopeasy.model.Order;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {
    
    private List<Order> orders = new ArrayList<>();
    private int nextOrderId = 1001;
    
    public Order createOrder(Cart cart, String customerName, String customerEmail, 
                            String customerPhone, String shippingAddress) {
        Order order = new Order();
        order.setId(nextOrderId++);
        order.setCustomerName(customerName);
        order.setCustomerEmail(customerEmail);
        order.setCustomerPhone(customerPhone);
        order.setShippingAddress(shippingAddress);
        order.setItems(new ArrayList<>(cart.getItems()));
        order.setTotalAmount(cart.getTotalPrice());
        order.setStatus("CONFIRMED");
        
        orders.add(order);
        return order;
    }
    
    public Order getOrderById(int orderId) {
        for (Order order : orders) {
            if (order.getId() == orderId) {
                return order;
            }
        }
        return null;
    }
    
    public List<Order> getAllOrders() {
        return orders;
    }
    
    public List<Order> getOrdersByEmail(String email) {
        List<Order> userOrders = new ArrayList<>();
        for (Order order : orders) {
            if (order.getCustomerEmail().equalsIgnoreCase(email)) {
                userOrders.add(order);
            }
        }
        return userOrders;
    }
}
