# ShopEasy / TravelEasy Application - URL Reference

**Base URL:** `http://localhost:8080`

---

## 🏠 Home & Authentication

| URL | Description |
|-----|-------------|
| `/` | Home Page |
| `/login` | User Login Page |
| `/register` | User Registration Page |
| `/logout` | Logout |
| `/profile` | User Profile |

---

## ✈️ Travel - Flights

| URL | Description |
|-----|-------------|
| `/travel` | Travel Home Page |
| `/travel/flights` | Browse Flights |
| `/travel/flights/book/{id}` | Book a Flight |

---

## 🚌 Travel - Buses

| URL | Description |
|-----|-------------|
| `/travel/buses` | Browse Buses |
| `/travel/buses/book/{id}` | Book a Bus |

---

## 📋 Bookings & Trips

| URL | Description |
|-----|-------------|
| `/travel/my-bookings` | View My Bookings |
| `/travel/booking-confirmation/{id}` | Booking Confirmation |
| `/travel/cancel-booking/{id}` | Cancel Booking |
| `/travel/trips` | View My Trips |
| `/travel/trips/new` | Create New Trip |
| `/travel/trips/{id}` | View Trip Details |
| `/travel/trips/{tripId}/remove-item/{itemId}` | Remove Item from Trip |

---

## 💰 Wallet

| URL | Description |
|-----|-------------|
| `/travel/wallet` | Wallet Page |

---

## 🛒 Shopping

| URL | Description |
|-----|-------------|
| `/products` | Browse Products |
| `/product/{id}` | Product Details |
| `/cart` | Shopping Cart |
| `/cart/add/{productId}` | Add to Cart |
| `/cart/remove/{productId}` | Remove from Cart |
| `/cart/increase/{productId}` | Increase Quantity |
| `/cart/decrease/{productId}` | Decrease Quantity |
| `/checkout` | Checkout Page |
| `/order-confirmation/{orderId}` | Order Confirmation |
| `/my-orders` | My Orders |

---

## 🧪 Test Features (for Selenium Practice)

| URL | Description |
|-----|-------------|
| `/test-features` | Test Features Page |
| `/iframe-content` | iFrame Content |
| `/new-window` | New Window Page |
| `/dynamic-content` | Dynamic Content Page |

---

## 📞 Extra Features

| URL | Description |
|-----|-------------|
| `/offers` | Offers Page |
| `/reviews` | Reviews Page |
| `/contact` | Contact Page |
| `/seat-selection/{bookingType}/{id}` | Seat Selection |
| `/settings` | Settings Page |
| `/help` | Help Page |
| `/help/faq` | FAQ Page |
| `/notifications` | Notifications Page |
| `/api/notifications` | Notifications API |

---

## 🔐 Admin Panel

| URL | Description |
|-----|-------------|
| `/admin/login` | Admin Login |
| `/admin/logout` | Admin Logout |
| `/admin/dashboard` | Admin Dashboard |
| `/admin/bookings` | Manage Bookings |
| `/admin/bookings/{id}` | Booking Details |
| `/admin/users` | Manage Users |
| `/admin/users/{id}` | User Details |
| `/admin/flights` | Manage Flights |
| `/admin/buses` | Manage Buses |

---

## 🚀 How to Run

```bash
cd D:\java\shopeasy\shopeasy
mvnw.cmd spring-boot:run
```

Then open: `http://localhost:8080`

---

## 👤 Test Credentials

| Role | Email | Password |
|------|-------|----------|
| User | test@example.com | password123 |
| Admin | admin@traveleasy.com | admin123 |
